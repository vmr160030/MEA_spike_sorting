Only do all code writing in dev branch and merge it to master only after code review. Other development branches should spin off from the dev brancha nd not master branch.
